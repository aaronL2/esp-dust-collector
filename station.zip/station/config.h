#pragma once

#define WIFI_SSID       "Landry"
#define FRIENDLY_NAME   "station"

#define SERVO_PIN       14
#define CURRENT_PIN     34
