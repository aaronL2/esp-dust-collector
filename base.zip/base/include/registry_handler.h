#pragma once
#include <ESPAsyncWebServer.h>

void setupRegistryRoutes(AsyncWebServer& server);
