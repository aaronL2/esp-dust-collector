#pragma once
#include <Arduino.h>
#include <esp_now.h>
#include <WiFi.h>

void comms_setup();
